package com.example.chatthem.chats.create_new_group_chat.view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.chatthem.R;
import com.example.chatthem.databinding.ActivityCreateGroupChatBinding;
import com.example.chatthem.utilities.Helpers;
import com.example.chatthem.utilities.PreferenceManager;

public class CreateGroupChatActivity extends AppCompatActivity {


    private ActivityCreateGroupChatBinding binding;
    private PreferenceManager preferenceManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCreateGroupChatBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Helpers.setupUI(binding.getRoot(), this);
    }

    private void setListener(){
        binding.imageBack.setOnClickListener(v->{
            onBackPressed();
        });
    }
}