package com.example.chatthem.chats.create_new_private_chat.view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.chatthem.R;

public class CreatePrivateChatActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_private_chat);
    }
}