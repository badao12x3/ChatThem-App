package com.example.chatthem.chats.group_chat_info.view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.chatthem.R;

public class GroupChatInfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_chat_info);
    }
}