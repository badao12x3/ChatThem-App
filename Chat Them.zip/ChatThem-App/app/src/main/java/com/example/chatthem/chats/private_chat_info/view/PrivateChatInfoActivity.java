package com.example.chatthem.chats.private_chat_info.view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.chatthem.R;

public class PrivateChatInfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_private_chat_info);
    }
}