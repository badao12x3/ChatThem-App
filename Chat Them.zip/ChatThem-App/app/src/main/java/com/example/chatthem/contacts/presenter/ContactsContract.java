package com.example.chatthem.contacts.presenter;

public class ContactsContract {
    interface PresenterInterface {
        // Interface này dành cho SignUpPresenter
    }
    interface ViewInterface {
        // Interface này dành cho SignUpActivity
    }
}
