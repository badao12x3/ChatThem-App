package com.example.chatthem.profile.presenter;

public class ChangePassContract {
    public interface ViewInterface{
        void onChangePassSuccess();
    }
}
