package com.example.chatthem.profile.presenter;

import com.example.chatthem.utilities.PreferenceManager;

public class ChangePassPresenter {
    
    private final ChangePassContract.ViewInterface viewInterface;
    private final PreferenceManager preferenceManager;

    public ChangePassPresenter(ChangePassContract.ViewInterface viewInterface, PreferenceManager preferenceManager) {
        this.viewInterface = viewInterface;
        this.preferenceManager = preferenceManager;
    }

    public void changePass() {


    }
}
