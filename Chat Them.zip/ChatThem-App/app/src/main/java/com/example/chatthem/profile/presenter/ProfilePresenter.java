package com.example.chatthem.profile.presenter;

public class ProfilePresenter {
    public void editProfile() {

    }
}
