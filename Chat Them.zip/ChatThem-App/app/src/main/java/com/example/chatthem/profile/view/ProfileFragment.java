package com.example.chatthem.profile.view;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.transition.AutoTransition;
import android.transition.TransitionManager;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.chatthem.R;
import com.example.chatthem.databinding.FragmentChatsBinding;
import com.example.chatthem.databinding.FragmentProfileBinding;
import com.example.chatthem.profile.presenter.ProfileContract;
import com.example.chatthem.profile.presenter.ProfilePresenter;
import com.example.chatthem.utilities.Constants;
import com.example.chatthem.utilities.Helpers;
import com.example.chatthem.utilities.PreferenceManager;
import com.github.dhaval2404.imagepicker.ImagePicker;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.HashMap;

public class ProfileFragment extends Fragment implements ProfileContract.ViewInterface {

    private FragmentProfileBinding binding;

    private PreferenceManager preferenceManager;

    private ProfilePresenter profilePresenter;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentProfileBinding.inflate(inflater,container,false);
        View rootView = binding.getRoot();
        Helpers.setupUI(binding.getRoot(),requireActivity());

        setListener();

        return rootView;
    }

    private void setListener(){
        binding.include.logout.setOnClickListener(v -> {

        });
        binding.itemInfo.btnAdd.setOnClickListener(v -> onAddPhoneNumberPressed());
        binding.itemInfo.btnOK.setOnClickListener(v -> {
            if (isValidPhone(binding.itemInfo.editTextPhoneNumber.getText().toString().trim())){
                onOKPhoneNumberPressed();
            }
        });
        binding.itemInfo.btnHide.setOnClickListener(v -> onCancelPhoneNumberPressed());
        binding.include.icEdit.setOnClickListener(v -> onEditNamePressed());

        binding.itemInfo.btnCancel.setOnClickListener(v -> onCancelPhoneEditPressed());
        binding.itemInfo.icEdit.setOnClickListener(v -> onEditPhonePressed());
        binding.include.btnChangePass.setOnClickListener(v -> {
            startActivity(new Intent(requireContext(), ChangePasswordActivity.class));
        });

        binding.include.genQrCode.setOnClickListener(x -> {
            onAddDevicePressed();
        });

        binding.include.updateProfileImg.setOnClickListener(view -> onUpdateProfileImgPressed());
        binding.include.imageProfile.setOnClickListener(view -> {

        });

        binding.itemAdd.btnAdd.setOnClickListener(view -> onAddAdressPressed());
        binding.itemAdd.btnOK.setOnClickListener(view -> {
            if (isValidAdress()) {
                onOKAdressPressed();
            }
        });
        binding.itemAdd.icEdit.setOnClickListener(view -> onEditAdressPressed());
        binding.itemAdd.btnCancel.setOnClickListener(view -> onCancelAdressPressed());
        binding.itemAdd.icHide.setOnClickListener(view -> onHideAdressPressed());
    }
    private void onAddAdressPressed() {
        binding.itemAdd.btnAdd.setVisibility(View.GONE);
        binding.itemAdd.btnCancel.setVisibility(View.GONE);
        binding.itemAdd.icHide.setVisibility(View.VISIBLE);
        TransitionManager.beginDelayedTransition(binding.layoutscroll, new AutoTransition());
        binding.itemAdd.containerEditAddres.setVisibility(View.VISIBLE);
        binding.itemAdd.containerBtn.setVisibility(View.VISIBLE);
    }
    private void onEditAdressPressed() {
        if(binding.itemAdd.btnCancel.getVisibility() == View.GONE){
            binding.itemAdd.btnCancel.setVisibility(View.VISIBLE);
        }
        binding.itemAdd.icEdit.setVisibility(View.GONE);
        TransitionManager.beginDelayedTransition(binding.layoutscroll, new AutoTransition());
        binding.itemAdd.containerAddress.setVisibility(View.GONE);
        binding.itemAdd.containerEditAddres.setVisibility(View.VISIBLE);
        binding.itemAdd.containerBtn.setVisibility(View.VISIBLE);
    }
    private void onCancelAdressPressed() {

        binding.itemAdd.icEdit.setVisibility(View.VISIBLE);
        TransitionManager.beginDelayedTransition(binding.layoutscroll, new AutoTransition());

        binding.itemAdd.containerEditAddres.setVisibility(View.GONE);
        binding.itemAdd.containerBtn.setVisibility(View.GONE);
        binding.itemAdd.containerAddress.setVisibility(View.VISIBLE);
    }
    private void onHideAdressPressed() {

        binding.itemAdd.icHide.setVisibility(View.GONE);
        binding.itemAdd.btnAdd.setVisibility(View.VISIBLE);
        TransitionManager.beginDelayedTransition(binding.layoutscroll, new AutoTransition());
        binding.itemAdd.containerEditAddres.setVisibility(View.GONE);
        binding.itemAdd.containerBtn.setVisibility(View.GONE);
    }
    private void onUpdateProfileImgPressed() {
        ImagePicker.with(this)
                .cropSquare()//Crop image(Optional), Check Customization for more option
                .compress(1024)			//Final image size will be less than 1 MB(Optional)
                .maxResultSize(1080, 1080)	//Final image resolution will be less than 1080 x 1080(Optional)
                .start();
    }

    private void onOKAdressPressed(){

        HashMap<String, Object> user = new HashMap<>();
        user.put(Constants.KEY_ADDRESS_CITY, binding.itemAdd.editTextCity.getText().toString());
        user.put(Constants.KEY_ADDRESS_PROVINCE, binding.itemAdd.editTextProvince.getText().toString());
        user.put(Constants.KEY_ADDRESS_TOWN, binding.itemAdd.editTextTown.getText().toString());
        user.put(Constants.KEY_ADDRESS_STREET, binding.itemAdd.editTextStreet.getText().toString());
        user.put(Constants.KEY_ADDRESS_NUMBER, binding.itemAdd.editTextNumber.getText().toString());


//        documentReference.update(user)
//                .addOnSuccessListener(v->{
//                    preferenceManager.putString(Constants.KEY_ADDRESS_CITY, binding.itemAdd.editTextCity.getText().toString());
//                    preferenceManager.putString(Constants.KEY_ADDRESS_PROVINCE, binding.itemAdd.editTextProvince.getText().toString());
//                    preferenceManager.putString(Constants.KEY_ADDRESS_TOWN, binding.itemAdd.editTextTown.getText().toString());
//                    preferenceManager.putString(Constants.KEY_ADDRESS_STREET, binding.itemAdd.editTextStreet.getText().toString());
//                    preferenceManager.putString(Constants.KEY_ADDRESS_NUMBER, binding.itemAdd.editTextNumber.getText().toString());
//                    binding.itemAdd.icHide.setVisibility(View.GONE);
//                    TransitionManager.beginDelayedTransition(binding.layoutscroll, new AutoTransition());
//                    binding.itemAdd.containerEditAddres.setVisibility(View.GONE);
//                    binding.itemAdd.containerBtn.setVisibility(View.GONE);
//                    binding.itemAdd.btnAdd.setVisibility(View.GONE);
//                    binding.itemAdd.textCity.setText(binding.itemAdd.editTextCity.getText().toString());
//                    binding.itemAdd.textAddressProvince.setText(binding.itemAdd.editTextProvince.getText().toString());
//                    binding.itemAdd.textAddressTown.setText(binding.itemAdd.editTextTown.getText().toString());
//                    binding.itemAdd.textAddressStreet.setText(binding.itemAdd.editTextStreet.getText().toString());
//                    binding.itemAdd.textAddressNumber.setText(binding.itemAdd.editTextNumber.getText().toString());
//                    binding.itemAdd.containerAddress.setVisibility(View.VISIBLE);
//                    binding.itemAdd.icEdit.setVisibility(View.VISIBLE);
//                    binding.itemAdd.editTextCity.getText().clear();
//                    binding.itemAdd.editTextProvince.getText().clear();
//                    binding.itemAdd.editTextTown.getText().clear();
//                    binding.itemAdd.editTextStreet.getText().clear();
//                    binding.itemAdd.editTextNumber.getText().clear();
//                })
//                .addOnFailureListener(e -> {
//                    showToast("Update Phone Number fail. Please try again!!");
//                });
    }
    private void onEditPhonePressed(){
        binding.itemInfo.btnCancel.setVisibility(View.VISIBLE);
        TransitionManager.beginDelayedTransition(binding.layoutscroll, new AutoTransition());
        binding.itemInfo.textPhone.setVisibility(View.GONE);
        binding.itemInfo.icEdit.setVisibility(View.GONE);
        binding.itemInfo.editTextPhoneNumber.setVisibility(View.VISIBLE);
        binding.itemInfo.containerBtn.setVisibility(View.VISIBLE);


    }
    private Boolean isValidAdress(){
        if (binding.itemAdd.editTextCity.getText().toString().trim().isEmpty()){
            showToast("Enter your City");
            return false;
        }else if(binding.itemAdd.editTextProvince.getText().toString().trim().isEmpty()){
            showToast("Enter your Province");
            return false;
        }else if(binding.itemAdd.editTextTown.getText().toString().trim().isEmpty()){
            showToast("Enter your Town");
            return false;
        }else if(binding.itemAdd.editTextStreet.getText().toString().trim().isEmpty()){
            showToast("Enter your Street");
            return false;
        }else if(binding.itemAdd.editTextNumber.getText().toString().trim().isEmpty()){
            showToast("Enter your No. ");
            return false;
        }
        return true;
    }
    private void onOKPhoneNumberPressed(){

        String textPhone = binding.itemInfo.editTextPhoneNumber.getText().toString().trim();

        profilePresenter.editProfile();

    }
    private void onEditNamePressed() {
        // Sử dụng LayoutInflater để tạo ra view từ tệp tin layout tùy chỉnh
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.custom_dialog_layout, null);

        // Lấy tham chiếu đến các phần tử trong layout tùy chỉnh
        TextView textViewTitle = dialogView.findViewById(R.id.textViewTitle);
        EditText editTextName = dialogView.findViewById(R.id.edit_text_name);
        Button buttonOK = dialogView.findViewById(R.id.btn_OK);
        Button buttonEnd = dialogView.findViewById(R.id.btn_Cancel);

        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setView(dialogView);

        final AlertDialog alertDialog = builder.create();

        // Ngăn người dùng đóng Alert Dialog bằng cách bấm ra bên ngoài
        alertDialog.setCanceledOnTouchOutside(false);

        // Ngăn người dùng đóng Alert Dialog bằng cách bấm nút Back
        alertDialog.setCancelable(false);
        buttonEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog.cancel();
            }
        });
        alertDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                buttonOK.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String newName = editTextName.getText().toString().trim();
                        if (!newName.isEmpty() && !Patterns.DOMAIN_NAME.matcher(editTextName.getText().toString()).matches()) {
                            // Thay đổi tên người dùng thành newName ở đây

//                            documentReference.update(Constants.KEY_NAME,editTextName.getText().toString())
//                                    .addOnSuccessListener(unused -> {
//                                        preferenceManager.putString(Constants.KEY_NAME, editTextName.getText().toString());
//                                        binding.include.textName.setText(editTextName.getText().toString());
//                                        alertDialog.dismiss();
//                                    })
//                                    .addOnFailureListener(e -> {
//                                        showToast("Update name false, please try again!!");
//                                    });

                        } else {
                            Toast.makeText(requireContext(), "Please enter a valid name", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
        alertDialog.show();
    }
    private void onCancelPhoneNumberPressed(){
        binding.itemInfo.btnHide.setVisibility(View.GONE);
        binding.itemInfo.btnAdd.setVisibility(View.VISIBLE);
        TransitionManager.beginDelayedTransition(binding.layoutscroll, new AutoTransition());
        binding.itemInfo.editTextPhoneNumber.setVisibility(View.GONE);
        binding.itemInfo.containerBtn.setVisibility(View.GONE);
    }
    private void onCancelPhoneEditPressed(){
        binding.itemInfo.editTextPhoneNumber.setVisibility(View.GONE);
        binding.itemInfo.btnCancel.setVisibility(View.GONE);
        TransitionManager.beginDelayedTransition(binding.layoutscroll, new AutoTransition());
        binding.itemInfo.textPhone.setVisibility(View.VISIBLE);
        binding.itemInfo.icEdit.setVisibility(View.VISIBLE);

        binding.itemInfo.containerBtn.setVisibility(View.GONE);

    }
    private Boolean isValidPhone(String textPhone){
        if (textPhone.isEmpty()){
            showToast("Enter your phone first!");
            return false;
        }else if(!Patterns.PHONE.matcher(textPhone).matches()){
            showToast("Enter valid phone number");
            return false;
        }
        return true;
    }
    private void showToast (String message){
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show();
    }

    private void onAddPhoneNumberPressed(){

//        TransitionManager.beginDelayedTransition(binding.itemInfo.cardview, new AutoTransition());
        binding.itemInfo.btnAdd.setVisibility(View.GONE);
        binding.itemInfo.btnHide.setVisibility(View.VISIBLE);
        TransitionManager.beginDelayedTransition(binding.layoutscroll, new AutoTransition());
        binding.itemInfo.editTextPhoneNumber.setVisibility(View.VISIBLE);
        binding.itemInfo.containerBtn.setVisibility(View.VISIBLE);
//        binding.itemInfo.container.startAnimation(slideUp);

    }
    private void onAddDevicePressed() {
        // Sử dụng LayoutInflater để tạo ra view từ tệp tin layout tùy chỉnh
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_warning, null);

        // Lấy tham chiếu đến các phần tử trong layout tùy chỉnh
        EditText editTextName = dialogView.findViewById(R.id.edit_text_name);
        Button buttonOK = dialogView.findViewById(R.id.btn_OK);
        Button buttonEnd = dialogView.findViewById(R.id.btn_Cancel);

        AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
        builder.setView(dialogView);

        final AlertDialog alertDialog = builder.create();

        // Ngăn người dùng đóng Alert Dialog bằng cách bấm ra bên ngoài
        alertDialog.setCanceledOnTouchOutside(false);

        // Ngăn người dùng đóng Alert Dialog bằng cách bấm nút Back
        alertDialog.setCancelable(false);
        buttonEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog.cancel();
            }
        });
        alertDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                buttonOK.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String pass = editTextName.getText().toString().trim();
                        if (!pass.isEmpty() && pass.equals(preferenceManager.getString(Constants.KEY_PASSWORD))) {
                            startActivity(new Intent(requireContext(), QR_code.class));
                            alertDialog.dismiss();
                        } else {
                            Toast.makeText(requireActivity(), "Wrong Password", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
        alertDialog.show();
    }

    @Override
    public void onEditProfileSuccess() {
        preferenceManager.putString(Constants.KEY_PHONE, "textPhone");
        binding.itemInfo.btnHide.setVisibility(View.GONE);
        TransitionManager.beginDelayedTransition(binding.layoutscroll, new AutoTransition());
        binding.itemInfo.editTextPhoneNumber.setVisibility(View.GONE);
        binding.itemInfo.containerBtn.setVisibility(View.GONE);
        binding.itemInfo.btnAdd.setVisibility(View.GONE);
        binding.itemInfo.textPhone.setText("textPhone");
        binding.itemInfo.textPhone.setVisibility(View.VISIBLE);
        binding.itemInfo.icEdit.setVisibility(View.VISIBLE);
    }

    @Override
    public void onEditProfileError() {

    }
}